<?php

require_once(dirname(__FILE__) . '/../../config.php');
require_once("$CFG->dirroot/mod/ptogo/lib.php");
require_once("$CFG->dirroot/mod/ptogo/locallib.php");


defined('MOODLE_INTERNAL') || die();

$settings = new admin_externalpage('activitysettingP2Go',
    get_string('modulename', 'ptogo'),
    new moodle_url('/mod/ptogo/repository.php'),
    'mod/ptogo:addrepository');