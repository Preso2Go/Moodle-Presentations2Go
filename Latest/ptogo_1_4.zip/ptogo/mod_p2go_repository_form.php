<?php
if (!defined('MOODLE_INTERNAL')) {
    die('Direct access to this script is forbidden.');    ///  It must be included from a Moodle page
}

global $CFG;
require_once("$CFG->libdir/formslib.php");
require_once("locallib.php");

class mod_p2go_repository_form extends moodleform {
    
    function definition() {

        $mform = $this->_form;

        $mform->addElement('text','title', get_string('repository_title', 'ptogo'));
        $mform->setType('title', PARAM_TEXT);

        $mform->addElement('text','description', get_string('repository_description', 'ptogo'));
        $mform->setType('description', PARAM_TEXT);

        $mform->addElement('text', 'serverurl', get_string('serverurl','ptogo'));
        $mform->setType('serverurl', PARAM_TEXT);
        $mform->setDefault('serverurl', 'https://serverurl/');

        $mform->addElement('text', 'secretkey', get_string('secretkey','ptogo'));
        $mform->setType('secretkey', PARAM_TEXT);
        $mform->setDefault('secretkey', 'enter key');

        $mform->addElement('text', 'p2go_group', get_string('group', 'ptogo'));
        $mform->setType('p2go_group', PARAM_NOTAGS);

        $mform->addElement('text', 'access_duration', get_string('duration', 'ptogo'));
        $mform->setType('access_duration', PARAM_INT);

        $mform->addElement('html', '<div id="queryWizardContainer"></div>');
        $mform->addElement('html', '<div id="preview"></div>');

        $item = $mform->addElement('hidden', 'p2go_item_id', '');
        $mform->setType('p2go_item_id', PARAM_TEXT);
        $item->updateAttributes(array('id' => 'id_p2go_item_id'));

        $mform->addElement('html', '<script>

        function attachNewEvent() {
            document.getElementById("search").addEventListener("click", function() {
               var preview =  new itemPreview("id_p2go_item_id", "' . get_string("item_add", "ptogo") . '", "' . new moodle_url("/mod/ptogo/") . '", false);
            });
        }

            document.getElementById("id_p2go_group").addEventListener("blur", function() {
                var queryWzard = new queryWizard("id_baseQuery", "' . get_string("query_add", "ptogo") . '", "' . new moodle_url("/mod/ptogo/") . '");
            });
        </script>');

        $mform->addElement('text', 'baseQuery', ' ');
        $mform->setType('baseQuery', PARAM_TEXT);

        $this->add_action_buttons(true, get_string('repository_add', 'ptogo'));
    }

    function validate($data) {
        if($data) {
            if(doesnotstartwith($data['server_url'], array('http://','https://'))) {
                $errors['server_url'] = getstring('serverurl_error', 'ptogo');
            }
        }
        return $errors;
    }
}