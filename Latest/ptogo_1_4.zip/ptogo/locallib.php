<?php

require_once(dirname(__FILE__) . '/../../config.php');
require_once('classes/class-p2go-web-api.php');

function doesnotstartwith($key, $options) {
    if(!is_string($key) || !is_array($options)) {
        return false;
    }
    for($i=0;$i<count($options);$i++) {
        $length = trim($options[$i]);
        if(substr($key,0, $length) === $options[$i]) {
            return true;
        }
    }
    return false;

}

function P2Go_get_selection($repository, $addQuery) {
    global $DB;
    $repositorydata = $DB->get_record('p2go_repository', array('id'=>(int) $repository));
    $basequery = $repositorydata->basequery;
    $query = $basequery . " AND " . $addQuery;
    $token = new P2GoWebApiToken();
    $query = new P2GoWebApiQuery($query, $DB);
    $expiration = 3;
    $group = $repositorydata->p2go_group;
    $server = $repositorydata->serverurl;
    if(substr($server,-1,1) === "/") {
        $server = substr($server,0, strlen($server)-1);
    }
    $P2GoAPI = new P2GoWebApi($server, $group, $expiration, $repositorydata->secretkey,"advancedsearch");
    $result = $P2GoAPI->makeRequest($token, $query);
    return $result;


}

function P2Go_get_selection_by_server($server,$key,$group,$addQuery) {
    global $DB;
    $token = new P2GoWebApiToken();
    $query = new P2GoWebApiQuery($addQuery, $DB);
    $expiration = 3;
    if(substr($server,-1,1) === "/") {
        $server = substr($server,0, strlen($server)-1);
    }
    $P2GoAPI = new P2GoWebApi($server, $group, $expiration, $key,"advancedsearch");
    $result = $P2GoAPI->makeRequest($token, $query);
    return $result;


}

function P2Go_process_response($id) {
    global $DB;

    $sql = "SELECT {ptogo}.*, {p2go_repository}.duration, {p2go_repository}.serverurl, {p2go_repository}.secretkey, {p2go_repository}.p2go_group, {p2go_repository}.basequery FROM {ptogo}
      INNER JOIN {p2go_repository} ON {p2go_repository}.id = {ptogo}.repository_id WHERE {ptogo}.course = ?"; //inner join.
    $post = $DB->get_record_sql($sql, array($id));
    $returnHTML = '<h1>' . $post->title .'</h1>';
    $returnHTML.= '<p>' . $post->description . '</p>';

    $query = $post->basequery;
    if(!empty($post->additional_query)) {
        $query.= " AND " . $post->additional_query;
    }

    if($post->video_id != null) {
        $itemquery = "SELECT * FROM {p2go_items}";
        $items = $DB->get_records_sql($itemquery, array('video_id' => $post->video_id));
    }

    $p2goQuery = new P2GoWebApiQuery($query, $DB);
    $p2goToken = new P2GoWebApiToken();
    $p2goAPI = new P2GoWebApi($post->serverurl, $post->p2go_group,  $post->duration, $post->secretkey, "advancedsearch");
    $response = json_decode($p2goAPI->makeRequest($p2goToken,$p2goQuery));

    if(isset($response->error) && $response->error !== "") {
        return "Error: " . $response->error;
    }
    foreach($response->response as $video) {
        if ($post->video_id != null) {
            for ($i = 1; $i <= count($items); $i++) {
                if ($video->id == $items[$i]->item_id) {
                    $returnHTML .= '<div class="displayItem">
                    <a href="' . $video->playbackUrl. '" target="_blank">
                    <figure>
                    <img src="' . $video->thumbnailUrl . '">
                    <div class="playbutton"></div>
                    </figure>
                    </a>
                    <div class="metaData">
                    <span>' . $video->title . '</span><br>
                    <span>' . $video->contributors . '</span><br>
                    <span>' .  processDate($video->date) . '</span>
                    </div>
</div>';
                }
            }
        } else {
            $returnHTML .= '<div class="displayItem">
                    <a href="' . $video->playbackUrl. '" target="_blank">
                    <figure>
                    <img src="' . $video->thumbnailUrl . '">
                    <div class="playbutton"></div>
                    </figure>
                    </a>
                    <div class="metaData">
                    <span>' . $video->title . '</span><br>
                    <span>' . $video->contributors . '</span><br>
                    <span>' .  processDate($video->date) . '</span>
                    </div>
</div>';
        }
    }
    return $returnHTML;
}

function processDate($datestr) {
//    2013-10-15T10:00:00
    $dateparts = explode('T', $datestr);
    return $dateparts[1] . " " . $dateparts[0];
}

function P2Go_get_filters($server, $key, $group) {
    global $DB;
    if(substr($server,-1,1) === "/") {
        $server = substr($server,0, strlen($server)-1);
    }
    $token = new P2GoWebApiToken();
    $query = new P2GoWebApiQuery('search', $DB);
    $expiration = 2;//the request becomes invalid after 2 minutes.
    $p2goAPI = new P2GoWebApi($server,$group, $expiration, $key, "info");
    $result = $p2goAPI->makeRequest($token, $query);
    return $result;
}

function P2Go_get_repository_data($id) {
    global $DB;
    $data = $DB->get_record('p2go_repository', array('id' => $id));
    $response = new stdClass();
    $response->serverurl = $data->serverurl;
    $response->secretkey = $data->secretkey;
    $response->p2go_group = $data->p2go_group;
    return json_encode($response);
}