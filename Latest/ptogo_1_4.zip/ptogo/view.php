<?php
require('../../config.php');



require_once("$CFG->dirroot/mod/ptogo/locallib.php");

$id = required_param('id', PARAM_INT);


list ($course, $cm) = get_course_and_cm_from_cmid($id);
$p2go = $DB->get_record('ptogo', array('id'=> $cm->instance), '*', MUST_EXIST);


$context = context_system::instance();
require_capability('mod/ptogo:view', $context);

require_login($course->id);

global $PAGE, $DB, $CFG, $OUTPUT;
$pagetitle = "test";
$PAGE->set_context($context);
$PAGE->set_url($CFG->wwwroot . '/mod/p2go/view.php', array("id"=>$course->id));
$PAGE->set_title($pagetitle);
$PAGE->set_pagelayout("incourse");
$PAGE->requires->css(new moodle_url("/mod/ptogo/view.css"));

global $OUTPUT;

echo $OUTPUT->header();

echo P2Go_process_response($course->id);

echo $OUTPUT->footer();