<?php


if (!defined('MOODLE_INTERNAL')) {
    die('Direct access to this script is forbidden.');    ///  It must be included from a Moodle page
}

require_once(dirname(__FILE__) . '/../../config.php');
require_once("$CFG->dirroot/course/moodleform_mod.php");

class mod_ptogo_mod_form extends moodleform_mod {
    function __construct($data, $section, $cm, $course)
    {

        parent::__construct($data, $section, $cm, $course);

        global $PAGE;

        $PAGE->requires->js(new moodle_url('/mod/ptogo/queryWizard/queryWizard.js'), true);
        $PAGE->requires->css(new moodle_url('/mod/ptogo/queryWizard/queryWizard.css'), true);
        $PAGE->requires->js(new moodle_url('/mod/ptogo/preview/preview.js'), true);
        $PAGE->requires->css(new moodle_url('/mod/ptogo/preview/preview.css'), true);
    }
    function definition() {
        global $CFG,$DB;

        $mform = $this->_form;

        $data = array();
        $options = array();
        $repositories = $DB->get_records('p2go_repository');

        for($i =1; $i<= count($repositories);$i++) {
            $options[$repositories[$i]->id] = $repositories[$i]->title;
            $data[] = $repositories[$i];
        }

        $mform->addElement('select', 'repository_id', 'repository', $options);

        $mform->addElement('text','title', get_string('page_title', 'ptogo'));
        $mform->setType('title', PARAM_TEXT);

        $mform->addElement('editor', 'description', get_string('page_description', 'ptogo'));
        $mform->setType('fieldname', PARAM_RAW);

        $radioarray = array();
        $radioarray[] =& $mform->createElement('radio', 'listitem', '', get_string('list' , 'ptogo'), 'list');
        $radioarray[] =& $mform->createElement('radio', 'listitem', '', get_string('item', 'ptogo'), 'item');
        $mform->addGroup($radioarray, 'radioar', '', array(' '), false);
        $mform->setDefault('listitem', 'list');

        $serverurl = $mform->addElement('hidden', 'serverurl', $repositories[1]->serverurl);
        $mform->setType('serverurl', PARAM_TEXT);

        $serverurl->updateAttributes(array('id' => 'id_serverurl'));


        $secretkey = $mform->addElement('hidden', 'secretkey', $repositories[1]->secretkey);
        $mform->setType('secretkey', PARAM_TEXT);
        $secretkey->updateAttributes(array('id' => 'id_secretkey'));

        $group = $mform->addElement('hidden', 'p2go_group', $repositories[1]->p2go_group);
        $mform->setType('p2go_group', PARAM_TEXT);
        $group->updateAttributes(array('id' => 'id_p2go_group'));

        $item = $mform->addElement('hidden', 'p2go_item_id', '');
        $mform->setType('p2go_item_id', PARAM_TEXT);
        $item->updateAttributes(array('id' => 'id_p2go_item_id'));

        //add content for queryWizard
        $mform->addElement('text', 'baseQuery', ' ');
        $mform->setType('baseQuery', PARAM_TEXT);

        $mform->addElement('html', '<div id="queryWizardContainer"></div>');
        $mform->addElement('html', '<div id="preview"></div>');

        $mform->addElement('html', '<script>
        document.getElementById("id_repository_id").addEventListener("change", function() {
            var id = document.getElementById("id_repository_id").options[document.getElementById("id_repository_id").selectedIndex].value;
            var xmlHttp = new XMLHttpRequest();
            xmlHttp.open("POST", "' . new moodle_url('/mod/ptogo/') . '" + "controller.php");
            xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlHttp.send("type=getRepositoryData&repository_id=" + id);

            xmlHttp.onload = function() {
                changeRepositoryData(xmlHttp.responseText);
            }
        });

        function changeRepositoryData(data) {
            var object = JSON.parse(data);
            var server = document.getElementById("id_serverurl");
            var key = document.getElementById("id_secretkey");
            var group = document.getElementById("id_p2go_group");

            server.value = object.serverurl;
            key.value = object.secretkey;
            group.value = object.p2go_group;
            new queryWizard("id_basequery", "' . get_string("query_add", "ptogo") . '", "' . new moodle_url("/mod/ptogo/") . '");
        }
    function attachNewEvent() {
        document.getElementById("search").addEventListener("click", function() {
            if(document.getElementById("id_listitem_item").checked) {
                var preview =  new itemPreview("id_p2go_item_id", "' . get_string("item_add", "ptogo") . '", "' . new moodle_url("/mod/ptogo/") . '", true);
            } else {
                var preview =  new itemPreview("id_p2go_item_id", "' . get_string("item_add", "ptogo") . '", "' . new moodle_url("/mod/ptogo/") . '", false);
            }
        });
    }

            new queryWizard("id_basequery", "' . get_string("query_add", "ptogo") . '", "' . new moodle_url("/mod/ptogo/") . '");
</script>');
        $this->standard_coursemodule_elements();
        $this->add_action_buttons(true, get_string('item_add', 'ptogo'));
    }

    function validation($data, $files) {
        $errors = array();
        parent::validation($data, $files);
        if(!is_numeric($data['repository_id'])) {
            $errors['repository'] = 'Don\'t hack';
        }
        return $errors;
    }
}