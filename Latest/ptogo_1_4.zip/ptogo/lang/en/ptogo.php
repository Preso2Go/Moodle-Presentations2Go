<?php

$string['modulename'] = 'Presentations 2Go';
$string['modulenameplural'] = 'Presentations 2Go';
$string['generalconfig'] = 'Presentations 2Go';
$string['explaingeneralconfig'] = 'Add a repository';
$string['serverurl'] = 'Location of your P2Go server';
$string['serverurl_desc'] = 'add the location of your Presentations 2Go server';
$string['serverurl_error'] = 'It looks like you mistyped the URL check the url before resubmitting';
$string['secretkey'] = 'secret key';
$string['secretkey_desc'] = 'The secret key is used to authorize';
$string['invalid_id'] = 'Invalid ID';
$string['embed'] = 'Embed rich media';
$string['duration'] = 'duration in hours, 0 is infinite';
$string['duration_not_numeric'] = 'There was an invalid value detected for the duration';
$string['duration_negative'] = 'Duration is not allowed to be negative';
$string['group'] = 'Group';
$string['embed_desc'] = 'Embed into page';
$string['repository_title'] = 'Title for the repository';
$string['repository_description'] = 'Description for the repository';
$string['repository_add'] = 'Add repository';
$string['query_wizard'] = 'Query wizard';
$string['query_add'] = 'Add query';
$string['item_add'] = 'Add item';
$string['list'] = 'list';
$string['item'] = 'Select items';
$string['page_title'] = 'Title of the videos';
$string['page_description'] = 'Page description';