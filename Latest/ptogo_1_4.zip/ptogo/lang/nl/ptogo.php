<?php

$string['modulename'] = 'Presentations 2Go';
$string['modulenameplural'] = 'Presentations 2Go';
$string['generalconfig'] = 'Presentations 2Go';
$string['explaingeneralconfig'] = 'Add a repository';
$string['serverurl'] = 'Locatie van de Presentations 2Go server';
$string['serverurl_desc'] = 'voeg de locatie van de Presenationts 2Go server toe';
$string['serverurl_error'] = 'Het lijkt er op dat u een typfout heeft gemaakt bij het invoeren van de server';
$string['secretkey'] = 'secret key';
$string['secretkey_desc'] = 'De secret key wordt gebruikt om te authoriseren';
$string['invalid_id'] = 'Invalid ID';
$string['embed'] = 'Embed rich media in de pagina';
$string['duration'] = 'duur in uren, 0 is oneindig';
$string['duration_not_numeric'] = 'De tijd moet numeriek zijn';
$string['duration_negative'] = 'De tijd mag niet negatief zijn';
$string['group'] = 'Groep';
$string['embed_desc'] = 'Embed rich media in de pagina';
$string['repository_title'] = 'Titel van de  repository';
$string['repository_description'] = 'Omschrijving van de repository';
$string['repository_add'] = 'Voeg repository toe';
$string['query_wizard'] = 'Query wizard';
$string['query_add'] = 'Voeg query toe';
$string['item_add'] = 'Voeg item(s) toe';
$string['list'] = 'lijst';
$string['item'] = 'Selecteer items';
$string['page_title'] = 'Titel van de pagina';
$string['page_description'] = 'Tekst binnen de pagina';