<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_ptogo';
$plugin->version = 2015081602;
$plugin->requires = 2015051100;
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.5';