<?php
require_once(dirname(__FILE__) . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once('mod_p2go_repository_list_form.php');

require_login();
$context = context_system::instance();

admin_externalpage_setup('activitysettingP2Go');
require_capability('mod/ptogo:addrepository', $context);
global $PAGE, $OUTPUT, $DB;

$repositories = $DB->get_records('p2go_repository');

$mform = new mod_p2go_repository_list_form($repositories);

echo $OUTPUT->header();

$mform->display();

echo $OUTPUT->footer();