<?php

require_once(dirname(__FILE__) . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');

require_once("mod_p2go_repository_add_form.php");

$id = optional_param('repository', 0, PARAM_INT);
require_login();
$context = context_system::instance();

admin_externalpage_setup('activitysettingP2Go');
require_capability('mod/ptogo:addrepository', $context);
global $PAGE, $OUTPUT,$DB;
$PAGE->set_context($context);
$PAGE->set_url($CFG->wwwroot . '/mod/ptogo/repository/add.php');

$mform = new mod_p2go_repository_add_form();

if ($mform->is_cancelled()) {
    // Go home
    redirect('repository.php');
}
$data = $mform->get_data();
if($data) {
    $record = new stdClass();
    $record->title = $data->title;
    $record->description = $data->description;
    $record->serverurl = $data->serverurl;
    $record->secretkey = $data->secretkey;
    $record->p2go_group = $data->p2go_group;
    $record->basequery = $data->baseQuery;
    $record->duration = $data->access_duration;
    $record->id = $data->id;

    $DB->update_record('p2go_repository', $record);
    // Go home
    redirect('repository.php');
}

echo $OUTPUT->header();

echo '<link rel="stylesheet" href="' . new moodle_url('/mod/ptogo/queryWizard/queryWizard.css') . '" type="text/css">';
echo '<link rel="stylesheet" href="' . new moodle_url('/mod/ptogo/preview/preview.css') . '" type="text/css">';

echo '<script src="' . new moodle_url('/mod/ptogo/preview/preview.js') . '"></script>';
echo '<script src="'. new moodle_url('/mod/ptogo/queryWizard/queryWizard.js') . '"></script>';

$formdata = $DB->get_record('p2go_repository', array("id" => $id));
$mform->set_data($formdata);
$mform->display();

echo $OUTPUT->footer();