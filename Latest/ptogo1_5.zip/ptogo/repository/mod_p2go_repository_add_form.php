<?php
if (!defined('MOODLE_INTERNAL')) {
    die('Direct access to this script is forbidden.');    ///  It must be included from a Moodle page
}

global $CFG;
require_once("$CFG->libdir/formslib.php");
require_once("../locallib.php");

class mod_p2go_repository_add_form extends moodleform {

    function definition() {
        global $DB;
        if(substr($this->_form->_attributes['action'], -8,4) == "edit") {
            $basequery = $DB->get_field_sql('SELECT basequery FROM {p2go_repository} WHERE id = (SELECT repository_id FROM {ptogo} WHERE id = (SELECT instance FROM {course_modules} WHERE id = ?))', array(intval($_GET['repository'])));

            $jsdata = new stdClass();
            $jsdata->query = $basequery;
            $jsdata->items = array();
            $jsdata = json_encode($jsdata);
        }

        $mform = $this->_form;

        $mform->addElement('text','title', get_string('repository_title', 'ptogo'));
        $mform->setType('title', PARAM_TEXT);

        $mform->addElement('text','description', get_string('repository_description', 'ptogo'));
        $mform->setType('description', PARAM_TEXT);

        $mform->addElement('text', 'serverurl', get_string('serverurl','ptogo'));
        $mform->setType('serverurl', PARAM_TEXT);
        $mform->setDefault('serverurl', 'https://serverurl/');

        $mform->addElement('text', 'secretkey', get_string('secretkey','ptogo'));
        $mform->setType('secretkey', PARAM_TEXT);
        $mform->setDefault('secretkey', 'enter key');

        $mform->addElement('text', 'p2go_group', get_string('group', 'ptogo'));
        $mform->setType('p2go_group', PARAM_NOTAGS);

        $mform->addElement('text', 'access_duration', get_string('duration', 'ptogo'));
        $mform->setType('access_duration', PARAM_INT);

        $mform->addElement('hidden', 'id', '');
        $mform->setType('id', PARAM_INT);

        $mform->addElement('html', '<div id="queryWizardContainer"></div>');
        $mform->addElement('html', '<div id="preview"></div>');

        $item = $mform->addElement('hidden', 'p2go_item_id', '');
        $mform->setType('p2go_item_id', PARAM_TEXT);
        $item->updateAttributes(array('id' => 'id_p2go_item_id'));

        $mform->addElement('html', '<script>

        function attachNewEvent() {
            document.getElementById("search").addEventListener("click", function() {
               var preview =  new itemPreview("id_p2go_item_id", "' . get_string("item_add", "ptogo") . '", "' . new moodle_url("/mod/ptogo/") . '", false);
            });
        }
            </script>');
        if(substr($this->_form->_attributes['action'], -8,4) == "edit") {

            $mform->addElement('html', '<script>
            var qw = new queryWizard("id_baseQuery", "' . get_string("query_add", "ptogo") . '", "' . new moodle_url("/mod/ptogo/") . '");
                window.onload = function() {
                    var preview =  new itemPreview("id_p2go_item_id", "' . get_string("item_add", "ptogo") . '", "' . new moodle_url("/mod/ptogo/") . '", false, ' . $jsdata . ');
                    var query = JSON.parse(JSON.stringify(' . $jsdata . ')).query;
                    var queryParts = query.split(" AND ");

                    for(var i=1,j=queryParts.length;i<j;i++) {
                        qw.addQuery();
                    }
                    for(var i=0,j=queryParts.length;i<j;i++) {
                            var tmpQuery = queryParts[i].split(" ");
                                setIndex(document.getElementById("subject"+i), tmpQuery[0]);
                                setIndex(document.getElementById("filter"+i), tmpQuery[1]);
                            if(document.getElementById("value"+i).tagName === "INPUT") {
                                document.getElementById("value"+i).value = tmpQuery[2] || "";
                            } else {
                                setIndex(document.getElementById("value"+i), tmpQuery[2]);
                            }
                        }

                    function setIndex(obj, value) {
                            var options = obj.options;
                            for(var i=0,j=options.length;i<j;i++) {
                                if(options[i].value == value) {
                                    obj.selectedIndex = i;
                                    return;
                                }
                            }
                        }
                    }
        </script>');
        } else {
            $mform->addElement('html',
            '<script>
            document.getElementById("id_p2go_group").addEventListener("blur", function() {
                var qw = new queryWizard("id_baseQuery", "' . get_string("query_add", "ptogo") . '", "' . new moodle_url("/mod/ptogo/") . '");
            });
        </script>');
        }


        $mform->addElement('text', 'baseQuery', ' ');
        $mform->setType('baseQuery', PARAM_TEXT);

        $this->add_action_buttons(true, get_string('repository_edit', 'ptogo'));
    }

    function validate($data) {
        if($data) {
            if(doesnotstartwith($data['server_url'], array('http://','https://'))) {
                $errors['server_url'] = getstring('serverurl_error', 'ptogo');
            }
        }
        return $errors;
    }
}