<?php

global $CFG;
require_once("$CFG->dirroot/lib/formslib.php");

class mod_p2go_repository_list_form extends moodleform
{
    private $repositories;

    public function __construct($repositories)
    {
        $this->repositories = $repositories;
        parent::__construct();
    }

    function definition()
    {
        $mform = $this->_form;

        global $OUTPUT;
        if (is_array($this->repositories) && count($this->repositories) > 0) {
            $table = new html_table();
            $table->head = array(get_string('repository_title', 'ptogo'), get_string('repository_description', 'ptogo'),
                get_string('repository_actions', 'ptogo'));

            foreach ($this->repositories as $repository) {
                $cells = array();
                $cells[] = new \html_table_cell($repository->title);
                $cells[] = new \html_table_cell($repository->description);
                $actionscell = $OUTPUT->action_icon(new moodle_url('/mod/ptogo/repository/edit.php',
                        array('repository' => $repository->id)),
                        new pix_icon('t/editstring', get_string('actionedit', 'ptogo')))
                    . " " .
                    $OUTPUT->action_icon(new moodle_url('/mod/ptogo/repository/delete.php',
                        array('repository' => $repository->id)),
                        new pix_icon('t/delete', get_string('actiondelete', 'ptogo')));
                $cells[] = $actionscell;
                $row = new html_table_row();
                $row->cells = $cells;
                $table->data[] = $row;
            }
            $mform->addElement('html', html_writer::table($table));
        } else {
            $mform->addElement('html',  '<p>' . get_string('nosrepositories', 'ptogo') . '</p>');
        }
        $mform->addElement('html','<a href=' . new moodle_url('/mod/ptogo/repository/add.php') . '><input type="button" id="id_addrepository" value="' . get_string('repository_add' , 'ptogo') . '"></a>');
    }
}