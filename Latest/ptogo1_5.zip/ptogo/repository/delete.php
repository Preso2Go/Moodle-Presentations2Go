<?php

require_once(dirname(__FILE__) . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');

$id = required_param('repository', PARAM_INT);
require_login();
$context = context_system::instance();

admin_externalpage_setup('activitysettingP2Go');
require_capability('mod/ptogo:addrepository', $context);

global $DB;

$DB->delete_records('p2go_items', array('video_id' => $DB->get_field_sql('SELECT video_id FROM {ptogo}', array("repository_id" => $id))));
$DB->delete_records('ptogo', array('repository_id' => $id));
$DB->delete_records('p2go_repository', array('id' => $id));

redirect('repository.php');