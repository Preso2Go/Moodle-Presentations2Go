<?php

function ptogo_add_instance($data) {

    global $DB, $CFG;
    $response = $DB->get_record_sql("SELECT MAX(video_id) AS maxID FROM {p2go_items}");
    $lastid = $response->maxid + 1;

    $result = new stdClass();
    $result->repository_id = $data->repository_id;
    $result->additional_query = $data->baseQuery;
    $result->title = $data->title;
    $result->intro = $data->intro['text'];
    $result->introformat = $data->intro['format'];
    $result->course = $data->course;
    $result->name = $data->name;


    if($data->listitem === "list") {
        $result->video_id = null;
    } else { //if($data->listitem === "item") {
        $items = explode(';', $data->p2go_item_id);
        $result->video_id = $lastid;
        for($i=0;$i<count($items);$i++){
            $item = new stdClass();
            $item->item_id = $items[$i];
            $item->video_id = $lastid;
            $DB->insert_record('p2go_items', $item);
        }
    }

    require_once("$CFG->libdir/resourcelib.php");

    $data->id = $DB->insert_record('ptogo', $result);


    return $data->id;
}

function ptogo_update_instance($data) {
    global $DB, $CFG;

    $response = $DB->get_record_sql("SELECT MAX(video_id) AS maxID FROM {p2go_items}");
    $lastid = $response->maxid;


    $result = new stdClass();
    $result->repository_id = $data->repository_id;
    $result->additional_query = $data->baseQuery;
    $result->title = $data->title;
    $result->video_id = null;
    $result->course = $data->course;
    $result->name = $data->name;
    $result->intro = $data->intro['text'];
    $result->introformat = $data->intro['format'];
    $result->id = $data->id;
    if($data->listitem === "list") {
        $result->video_id = null;
    } else {
        $items = explode(';', $data->p2go_item_id);
        $result->video_id = $lastid;
        for($i=0;$i<count($items);$i++){
            $item = new stdClass();
            $item->item_id = $items[$i];
            $item->video_id = $lastid;
            $DB->update_record('p2go_items', $item);
        }
    }

    require_once("$CFG->libdir/resourcelib.php");

    $cmid = $data->coursemodule;

    $data->id = $DB->update_record('ptogo', $result);

    return $data->id;
}

function ptogo_delete_instance($id) {
    global $DB;
    $response = $DB->get_record("SELECT {p2go_items}.video_id FROM {ptogo} INNER JOIN {p2go_items} ON {ptogo}.video_id = {p2go_items}.video_id", array("id" => $id));

    $DB->delete_records('p2go_items', array("video_id" => $response->video_id));
    $did = $DB->delete_records('ptogo',array("id"=> $id));


    return $did;

}