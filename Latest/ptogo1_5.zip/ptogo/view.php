<?php
require('../../config.php');



require_once("$CFG->dirroot/mod/ptogo/locallib.php");

$id = required_param('id', PARAM_INT);


list ($course, $cm) = get_course_and_cm_from_cmid($id);

$p2go = $DB->get_record('ptogo', array('id'=> $cm->instance), '*', MUST_EXIST);

require_course_login($course, true, $cm);

$context = context_system::instance();
require_capability('mod/ptogo:view', $context);

global $PAGE, $DB, $CFG, $OUTPUT;
$PAGE->set_url($CFG->wwwroot . '/mod/p2go/view.php', array("id"=>$id));
$PAGE->set_title($course->shortname.': '.$p2go->name);
$PAGE->set_heading($course->fullname);
$PAGE->requires->css(new moodle_url("/mod/ptogo/view.css"));
$PAGE->set_pagelayout("incourse");

global $OUTPUT;

echo $OUTPUT->header();

echo P2Go_process_response($course->id, $cm->instance);

echo $OUTPUT->footer();