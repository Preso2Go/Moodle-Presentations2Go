<?php

function xmldb_ptogo_upgrade($oldversion=0)
{
    global $CFG, $DB;

    $plugin = new stdClass();
    include("$CFG->dirroot/mod/mediasite/version.php");


    $dbman = $DB->get_manager();
    if ($oldversion < 2015081601) {

        // Rename field intro on table ptogo to NEWNAMEGOESHERE.
        $table = new xmldb_table('ptogo');
        $field = new xmldb_field('description', XMLDB_TYPE_TEXT, null, null, null, null, null, 'name');

        // Launch rename field intro.
        $dbman->rename_field($table, $field, 'intro');

        // P2go savepoint reached.
        upgrade_mod_savepoint(true, 2015081601, 'ptogo');
    }
    if($oldversion < 2015081602) {
        // Define field introformat to be added to ptogo.
        $table = new xmldb_table('ptogo');
        $field = new xmldb_field('introformat', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, '1', 'intro');

        // Conditionally launch add field introformat.
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        // P2go savepoint reached.
        upgrade_mod_savepoint(true, 2015081602, 'ptogo');
    }
}