<?php

function xmldb_ptogo_upgrade($oldversion=0)
{
    global $CFG, $DB;

    $plugin = new stdClass();
    include("$CFG->dirroot/mod/mediasite/version.php");


    $dbman = $DB->get_manager();
    if ($oldversion < 2015081601) {

        // Rename field intro on table ptogo to NEWNAMEGOESHERE.
        $table = new xmldb_table('ptogo');
        $field = new xmldb_field('description', XMLDB_TYPE_TEXT, null, null, null, null, null, 'name');

        // Launch rename field intro.
        $dbman->rename_field($table, $field, 'intro');

        // P2go savepoint reached.
        upgrade_mod_savepoint(true, 2015081601, 'ptogo');
    }
}