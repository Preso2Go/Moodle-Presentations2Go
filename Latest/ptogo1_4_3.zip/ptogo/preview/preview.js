function itemPreview(target, submitString, plugin_URL, hasRepository) {
    'use strict';
    var url = plugin_URL;
    var container = document.getElementById('preview');
    var response;
    var items = new Array();

    this.show = function() {

        while(container.hasChildNodes()) {
            container.removeChild(container.firstChild);
        };
        container.style.display = 'block';
        response = response.response;
        for(var i=0;i<response.length;i++) {

            var item = document.createElement('div');
            item.setAttribute('id', 'preview'+i);
            item.setAttribute('class', 'preview-item');

            var img = new Image();
            img.setAttribute('src', response[i].thumbnailUrl);
            img.setAttribute('class', 'preview-item--image');

            var title = document.createElement('span');
            title.setAttribute('class', 'preview-item--title');
            title.innerHTML = response[i].title;

            var checkbox = document.createElement('input');
            checkbox.setAttribute('type', 'checkbox');
            checkbox.setAttribute('value', response[i].id);
            checkbox.setAttribute('class', 'preview-item--select');

            item.appendChild(title);
            item.appendChild(img);

            if(hasRepository) {
                item.appendChild(checkbox);
            }

            container.appendChild(item);
        }

        if(hasRepository) {
            var submit = document.createElement('input');
            submit.setAttribute('type', 'button');
            submit.setAttribute('value', submitString);
            submit.addEventListener('click', function () {
                this.submit();
            }.bind(this));

            container.parentNode.insertBefore(submit, container.nextSibling);
        }
    };

    this.hide = function() {
        container.style.display = 'none';
    };

    this.submit = function() {
        var checkboxes = document.querySelectorAll('.preview-item--select');
        for(var i=0; i<checkboxes.length;i++) {
            if(checkboxes[i].checked) {
                items.push(checkboxes[i].value);
            }
        }
        document.getElementById(target).value = items.join(";");
    }.bind(this);

    this.getList = function() {
        var xmlHttp = new XMLHttpRequest();
        var addquery = document.getElementById('id_baseQuery').value;
        if (hasRepository) {
            var repository = document.getElementById('id_repository_id').options[document.getElementById('id_repository_id').selectedIndex].value;

            xmlHttp.open("POST", url + "controller.php");
            xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlHttp.send("type=preview&hasrepository=true&repository=" + repository + "&addQuery=" + encodeURIComponent(addquery));
        } else {
            var server = document.getElementById('id_serverurl').value;
            var key = document.getElementById('id_secretkey').value;
            var group = document.getElementById('id_p2go_group').value;

            xmlHttp.open("POST", url + "controller.php");
            xmlHttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xmlHttp.send("type=preview&hasrepository=false&server=" + server + "&key=" + key + "&group=" + group + "&addQuery=" + encodeURIComponent(addquery));
        }
        xmlHttp.onload = function () {
            response = JSON.parse(xmlHttp.responseText);
            return this.show();
        }.bind(this);
    };

    this.getList();
}