<?php
require_once('locallib.php');

switch($_POST['type']) {
   case "filter":
       if(isset($_POST['key']) && isset($_POST['server']) && isset($_POST['group'])) {
           echo  P2Go_get_filters($_POST['server'], str_replace(" ", "+",urldecode($_POST['key'])), $_POST['group']);
       }
        break;
    case "preview":
        if(isset($_POST['hasrepository']) && $_POST['hasrepository'] === "true") {
            if (isset($_POST['repository']) && isset($_POST['addQuery'])) {
                $repository = $_POST['repository'];
                $addQuery = urldecode($_POST['addQuery']);
                echo P2Go_get_selection($repository, $addQuery);
            }
        } else {
            if (isset($_POST['key']) && isset($_POST['server']) && isset($_POST['group']) && isset($_POST['addQuery'])) {
                $addQuery = urldecode($_POST['addQuery']);
                echo P2Go_get_selection_by_server($_POST['server'], str_replace(" ", "+",urldecode($_POST['key'])), $_POST['group'], $addQuery);
            }
        }
        break;
    case "getRepositoryData":
            if(isset($_POST['repository_id'])) {
                echo P2Go_get_repository_data((int) $_POST['repository_id']);
            }
        break;
    default:
        break;
}